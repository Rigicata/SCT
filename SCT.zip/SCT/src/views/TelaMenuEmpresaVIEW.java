/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;


import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;



/**
 *
 * @author Maresia-
 */
public class TelaMenuEmpresaVIEW extends javax.swing.JFrame {

    
    
    
    public TelaMenuEmpresaVIEW() {
        initComponents();
        
        
    }
    
    //////////PARTE Termo de Uso ////////////////////////////////////////
public void setColorBtn(JPanel panel){

    panel.setBackground(new java.awt.Color(204,204,255));
}

public void resetColorBtn(JPanel panel){
 
    panel.setBackground(new java.awt.Color(240,255,255));

}
/////////////////////////////////////////////////////////////////////  
    



   
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        label_Empresa = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Painel_Empresa = new javax.swing.JPanel();
        logo_Empresa = new javax.swing.JLabel();
        label_Empresa1 = new javax.swing.JLabel();
        Painel_Funcionario = new javax.swing.JPanel();
        logo_Empresa1 = new javax.swing.JLabel();
        label_Empresa2 = new javax.swing.JLabel();
        Painel_Contrato = new javax.swing.JPanel();
        logo_Empresa2 = new javax.swing.JLabel();
        label_Empresa3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(19, 19, 70));

        label_Empresa.setBackground(new java.awt.Color(240, 255, 255));
        label_Empresa.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Empresa.setForeground(new java.awt.Color(240, 255, 255));
        label_Empresa.setText("MENU");

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons8-clique-esquerdo-do-mouse-40.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(label_Empresa)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 663, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(label_Empresa)
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 80));

        jPanel2.setBackground(new java.awt.Color(240, 255, 255));

        Painel_Empresa.setBackground(new java.awt.Color(240, 255, 255));
        Painel_Empresa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(19, 19, 70), 10));
        Painel_Empresa.setToolTipText("ÁREA PARA EMPRESA");
        Painel_Empresa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Painel_Empresa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Painel_EmpresaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Painel_EmpresaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Painel_EmpresaMouseExited(evt);
            }
        });
        Painel_Empresa.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo_Empresa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons8-skyscrapers-80.png"))); // NOI18N
        Painel_Empresa.add(logo_Empresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 88, 80));

        label_Empresa1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Empresa1.setForeground(new java.awt.Color(19, 19, 70));
        label_Empresa1.setText("EMPRESA");
        Painel_Empresa.add(label_Empresa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 100, -1));

        Painel_Funcionario.setBackground(new java.awt.Color(240, 255, 255));
        Painel_Funcionario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(19, 19, 70), 10));
        Painel_Funcionario.setToolTipText("ÁREA PARA FUNCIONÁRIO");
        Painel_Funcionario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Painel_Funcionario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Painel_FuncionarioMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Painel_FuncionarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Painel_FuncionarioMouseExited(evt);
            }
        });
        Painel_Funcionario.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo_Empresa1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons8-chamada-em-conferência-80.png"))); // NOI18N
        Painel_Funcionario.add(logo_Empresa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 30, 90, 85));

        label_Empresa2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Empresa2.setForeground(new java.awt.Color(19, 19, 70));
        label_Empresa2.setText("FUNCIONÁRIO");
        Painel_Funcionario.add(label_Empresa2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 170, -1));

        Painel_Contrato.setBackground(new java.awt.Color(240, 255, 255));
        Painel_Contrato.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(19, 19, 70), 10));
        Painel_Contrato.setToolTipText("ÁREA PARA EMPRESA");
        Painel_Contrato.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Painel_Contrato.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Painel_ContratoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Painel_ContratoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Painel_ContratoMouseExited(evt);
            }
        });
        Painel_Contrato.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo_Empresa2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons8-acordo-80.png"))); // NOI18N
        Painel_Contrato.add(logo_Empresa2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 90, 80));

        label_Empresa3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label_Empresa3.setForeground(new java.awt.Color(19, 19, 70));
        label_Empresa3.setText("CONTRATO");
        Painel_Contrato.add(label_Empresa3, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 120, 110, -1));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(Painel_Empresa, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addComponent(Painel_Funcionario, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78)
                .addComponent(Painel_Contrato, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(100, 100, 100))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(142, 142, 142)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Painel_Contrato, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Painel_Funcionario, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Painel_Empresa, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(338, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 74, 870, 650));

        setSize(new java.awt.Dimension(855, 599));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Painel_EmpresaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_EmpresaMouseClicked
        TelaAtualizarEmpresaVIEW taev = new TelaAtualizarEmpresaVIEW();
        taev.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Painel_EmpresaMouseClicked

    private void Painel_EmpresaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_EmpresaMouseEntered
    setColorBtn(Painel_Empresa);
    }//GEN-LAST:event_Painel_EmpresaMouseEntered

    private void Painel_EmpresaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_EmpresaMouseExited
    resetColorBtn(Painel_Empresa);   
    }//GEN-LAST:event_Painel_EmpresaMouseExited

    private void Painel_FuncionarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_FuncionarioMouseClicked
        TelaConsultarFuncionarioVIEW tcfv = new TelaConsultarFuncionarioVIEW();
        tcfv.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Painel_FuncionarioMouseClicked

    private void Painel_FuncionarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_FuncionarioMouseEntered
    setColorBtn(Painel_Funcionario);    
    }//GEN-LAST:event_Painel_FuncionarioMouseEntered

    private void Painel_FuncionarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_FuncionarioMouseExited
    resetColorBtn(Painel_Funcionario);     
    }//GEN-LAST:event_Painel_FuncionarioMouseExited

    private void Painel_ContratoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_ContratoMouseClicked
        TelaContratoVIEW tcv = new TelaContratoVIEW();
        tcv.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Painel_ContratoMouseClicked

    private void Painel_ContratoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_ContratoMouseEntered
    setColorBtn(Painel_Contrato);     
    }//GEN-LAST:event_Painel_ContratoMouseEntered

    private void Painel_ContratoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Painel_ContratoMouseExited
     resetColorBtn(Painel_Contrato);     
    }//GEN-LAST:event_Painel_ContratoMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaInicialVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaInicialVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaInicialVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaInicialVIEW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaMenuEmpresaVIEW().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Painel_Contrato;
    private javax.swing.JPanel Painel_Empresa;
    private javax.swing.JPanel Painel_Funcionario;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel label_Empresa;
    private javax.swing.JLabel label_Empresa1;
    private javax.swing.JLabel label_Empresa2;
    private javax.swing.JLabel label_Empresa3;
    private javax.swing.JLabel logo_Empresa;
    private javax.swing.JLabel logo_Empresa1;
    private javax.swing.JLabel logo_Empresa2;
    // End of variables declaration//GEN-END:variables
}
